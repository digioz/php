<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); 

function LendrBuildRoute(&$query)
{
	$segments = array();
	return $segments;
}

function LendrParseRoute($segments) 
{

}