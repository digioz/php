<?php // no direct access

defined( '_JEXEC' ) or die( 'Restricted access' ); 
 
class LendrModelsBook extends LendrModelsDefault
{
  function __construct()
  {
    parent::__construct();       
  }
 
  function store()
  {
  
  }
 
  function getBook()
  {

  }
 
  function getBooks()
  {

  }
 
  function populateState()
  {

  }
}