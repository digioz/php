DROP TABLE IF EXISTS `#__stories_story`;
DROP TABLE IF EXISTS `#__stories_category`;
DROP TABLE IF EXISTS `#__stories_subcategory`;
DROP TABLE IF EXISTS `#__stories_rating`;
