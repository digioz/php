DROP TABLE IF EXISTS `#__links_link`;
DROP TABLE IF EXISTS `#__links_category`;
