<?php
/**
 * @version     1.0.2
 * @package     com_addressbook
 * @copyright   Copyright (C) DigiOz Multimedia. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Pete Soheil <webmaster@digioz.com> - http://www.digioz.com
 */
// no direct access
defined('_JEXEC') or die;

//Load admin language file
$lang = JFactory::getLanguage();
$lang->load('com_addressbook', JPATH_ADMINISTRATOR);

?>
<?php if ($this->item) : ?>

    <div class="item_fields">

        <ul class="fields_list">

            			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_ID'); ?>:
			<?php echo $this->item->id; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_FIRSTNAME'); ?>:
			<?php echo $this->item->firstname; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_MIDDLENAME'); ?>:
			<?php echo $this->item->middlename; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_LASTNAME'); ?>:
			<?php echo $this->item->lastname; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_COMPANY'); ?>:
			<?php echo $this->item->company; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_ADDRESS'); ?>:
			<?php echo $this->item->address; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_ADDRESS2'); ?>:
			<?php echo $this->item->address2; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_CITY'); ?>:
			<?php echo $this->item->city; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_STATENAME'); ?>:
			<?php echo $this->item->statename; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_COUNTRY'); ?>:
			<?php echo $this->item->country; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_EMAIL'); ?>:
			<?php echo $this->item->email; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_WEBSITE'); ?>:
			<?php echo $this->item->website; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_TWITTER'); ?>:
			<?php echo $this->item->twitter; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_FACEBOOK'); ?>:
			<?php echo $this->item->facebook; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_LINKEDIN'); ?>:
			<?php echo $this->item->linkedin; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_BIRTHDATE'); ?>:
			<?php echo $this->item->birthdate; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_WORKPHONE'); ?>:
			<?php echo $this->item->workphone; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_HOMEPHONE'); ?>:
			<?php echo $this->item->homephone; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_MOBILEPHONE'); ?>:
			<?php echo $this->item->mobilephone; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_FAX'); ?>:
			<?php echo $this->item->fax; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_CHECKED_OUT'); ?>:
			<?php echo $this->item->checked_out; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_ORDERING'); ?>:
			<?php echo $this->item->ordering; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_STATE'); ?>:
			<?php echo $this->item->state; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_CHECKED_OUT_TIME'); ?>:
			<?php echo $this->item->checked_out_time; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_CREATED_BY'); ?>:
			<?php echo $this->item->created_by; ?></li>
			<li><?php echo JText::_('COM_ADDRESSBOOK_FORM_LBL_ADDRESS_NOTES'); ?>:
			<?php echo $this->item->notes; ?></li>


        </ul>

    </div>
    
<?php
else:
    echo JText::_('COM_ADDRESSBOOK_ITEM_NOT_LOADED');
endif;
?>
