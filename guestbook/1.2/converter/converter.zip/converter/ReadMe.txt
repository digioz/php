How to convert DigiOz Version 1.0 Guestbook to Version 1.1:
-----------------------------------------------------------

1- Extract the contents of the converter.zip file. This creates a folder called "converter".
2- Copy and paste your list.txt file from your old guestbook into the converter folder.
3- Give Read, Write and Execute permission to the "converter" folder (CHMOD 777) and all it's content.
4- Run the file called "convert.php" by browsing in your Web Browser to this file.
5- The file is executed and your old database is converted automatically.
6- You can copy the converted file called "converted.txt", paste and rename it into your new guestbook version 1.1 installation folder . Don't forget to CHMOD the converted "list.txt" to 777.

-----------------------------------------------------------


As always, if you have any questions or need any help, feel free to contact us at digi_oz@yahoo.com with your specific question. 